# Mod Menu by Dil

Project Android simulator latihan aim offline. Ikon aplikasi menggunakan gambar profil yang diberikan pengguna. Termasuk target bergerak pseudo-3D dan pilihan warna garis visualizer.

## Build APK dari HP melalui GitHub Actions
1. Buat repository GitHub.
2. Ekstrak ZIP project dan upload seluruh isi folder ke repository, termasuk `.github`.
3. Commit perubahan.
4. Buka tab Actions dan jalankan workflow **Build Android APK**.
5. Setelah selesai, unduh artifact `FF-Headshot-Training-APK`, ekstrak, lalu pasang `app-debug.apk`.

Nama aplikasi: **Mod Menu by Dil**.

Catatan ukuran: APK saat ini ringan dan tidak ditargetkan 50 MB. Ukuran 50 MB tidak menambah fitur atau kualitas dengan sendirinya. Untuk ukuran lebih besar secara wajar, perlu menambahkan aset latihan offline yang nyata (misalnya model 3D, tekstur, dan audio), bukan data kosong.
